#pragma once
#ifndef _IOCP_LIB_H__ //IOCP ó���� ��Ƶ� ���̺귯��
#define READ 3
#define WRITE 5
#include <winsock2.h>
#include <stdlib.h>
#include <stdio.h>
#include <conio.h>
#include "SocketLib.h"
typedef struct file_io_port //IOCP �����忡 ��� �� ����ü
{
	HANDLE io_port;
	ClientInfoPointer client_info;
}FileIOPort, *FileIOPortPointer;
/*void IOBufferSetting(IOBufferPointer*);*/
DWORD WINAPI StartSendFileData(LPVOID);
DWORD WINAPI StartRecv(LPVOID);
DWORD WINAPI RecvFileData(LPVOID);
DWORD WINAPI SendFileData(LPVOID);
#endif
