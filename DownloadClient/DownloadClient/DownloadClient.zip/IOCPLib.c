#include "IOCPLib.h"
extern HANDLE thread_pool[THREAD_NUMBER];

DWORD WINAPI StartSendFileData(LPVOID iocp_port)
{
	FileIOPortPointer file_io_port = (FileIOPortPointer)iocp_port;
	DWORD byte_tran;
	HandleInfo handle_info;
	GetQueuedCompletionStatus(file_io_port->io_port, &byte_tran, (PULONG_PTR)&handle_info,
		(LPOVERLAPPED*)&(file_io_port->client_info->overlapped), INFINITE);

	for (int i = 0; i < THREAD_NUMBER; i++)
		thread_pool[i] = CreateThread(NULL, 0, SendFileData, (LPVOID)&(file_io_port->client_info), 0, NULL); //������ ����*/

	return 0;
}
DWORD WINAPI StartRecv(LPVOID iocp_port)
{
	FileIOPortPointer file_io_port = (FileIOPortPointer)iocp_port;
	DWORD byte_tran;
	HandleInfo handle_info;
	int buf_size;

	GetQueuedCompletionStatus(file_io_port->io_port, &byte_tran, (PULONG_PTR)&handle_info,
		(LPOVERLAPPED*)&(file_io_port->client_info->overlapped), INFINITE);

	file_io_port->client_info->file_info.file_size = GetFileSize(file_io_port->client_info->file_info.file, NULL);

	if (file_io_port->client_info->file_info.file_size < GIGABYTE)
	{
		buf_size = file_io_port->client_info->file_info.file_size / 5;
		file_io_port->client_info->file_info.temp_buffer = (char*)malloc(file_io_port->client_info->file_info.file_size / 5); //��ũ�� �������
	}
	else
	{
		buf_size = GIGABYTE / 5;
		file_io_port->client_info->file_info.temp_buffer = (char*)malloc(GIGABYTE / 5);
	}

	file_io_port->client_info->file_info.wsa_buf.len = buf_size;

	for (int i = 0; i < THREAD_NUMBER; i++)
		thread_pool[i] = CreateThread(NULL, 0, RecvFileData, (LPVOID)file_io_port, 0, NULL); //������ ����*/

	return 0;
}

DWORD WINAPI RecvFileData(LPVOID info)
{
	FileIOPortPointer file_io_port = (FileIOPortPointer)info;
	int recv_len, byte_tran, recv_data;
	HandleInfo handle_info;
	unsigned long recv_data = file_io_port->client_info->file_info.file_size;

	EnterCriticalSection(&(file_io_port->client_info->cs));
	if (file_io_port->client_info->file_info.file_size / 5 <
		file_io_port->client_info->file_info.file_size
		- file_io_port->client_info->file_info.is_file_send) //�����Ͱ� file_size/5 ���Ϸ� ����
	{
		WSARecv(file_io_port->client_info->sock, &(file_io_port->client_info->file_info.wsa_buf),
			recv_data, &recv_len, 0, &(file_io_port->client_info->overlapped), NULL);
		GetQueuedCompletionStatus(file_io_port->io_port, &byte_tran, (PULONG_PTR)&handle_info,
			(LPOVERLAPPED*)&(file_io_port->client_info->overlapped), INFINITE);

		fwrite(file_io_port->client_info->file_info.wsa_buf.buf,
			recv_data, recv_data, file_io_port->client_info->file_info.file);
		file_io_port->client_info->file_info.is_file_send += recv_data;
	}
	else
	{
		recv_data = file_io_port->client_info->file_info.file_size - file_io_port->client_info->file_info.is_file_send;
		WSARecv(file_io_port->client_info->sock, &(file_io_port->client_info->file_info.wsa_buf),
			recv_data, &recv_len, 0, &(file_io_port->client_info->overlapped), NULL);
		GetQueuedCompletionStatus(file_io_port->io_port, &byte_tran, (PULONG_PTR)&handle_info,
			(LPOVERLAPPED*)&(file_io_port->client_info->overlapped), INFINITE);

		fwrite(file_io_port->client_info->file_info.wsa_buf.buf, recv_data, recv_data, file_io_port->client_info->file_info.file);
	}
	LeaveCriticalSection(&(file_io_port->client_info->cs));

	return 0;
}

DWORD WINAPI SendFileData(LPVOID info)
{
	FileIOPortPointer file_io_port = (FileIOPortPointer)info;
	int recv_len,byte_tran;
	HandleInfo handle_info;
	unsigned long send_data = file_io_port->client_info->file_info.file_size / 5;

	EnterCriticalSection(&(file_io_port->client_info->cs));
	if (send_data <
		file_io_port->client_info->file_info.file_size 
		- file_io_port->client_info->file_info.is_file_send) //�����Ͱ� file_size/5 ���Ϸ� ����
	{
		fread_s(file_io_port->client_info->file_info.temp_buffer, send_data, 
			1, send_data, file_io_port->client_info->file_info.file);
		WSASend(file_io_port->client_info->sock, &(file_io_port->client_info->file_info.wsa_buf), send_data, &recv_len, 0, 
			&(file_io_port->client_info->overlapped), NULL);
		GetQueuedCompletionStatus(file_io_port->io_port, &byte_tran, (PULONG_PTR)&handle_info,
			(LPOVERLAPPED*)&(file_io_port->client_info->overlapped), INFINITE);
		file_io_port->client_info->file_info.is_file_send += send_data;
	}
	else
	{
		send_data = file_io_port->client_info->file_info.file_size - file_io_port->client_info->file_info.is_file_send;
		fread_s(file_io_port->client_info->file_info.temp_buffer, send_data, 1, 
			send_data, file_io_port->client_info->file_info.file);
		GetQueuedCompletionStatus(file_io_port->io_port, &byte_tran, (PULONG_PTR)&handle_info,
			(LPOVERLAPPED*)&(file_io_port->client_info->overlapped), INFINITE);
		WSASend(file_io_port->client_info->sock, &(file_io_port->client_info->file_info.wsa_buf), send_data,
			&recv_len, 0, &(file_io_port->client_info->overlapped), NULL);
	}
	LeaveCriticalSection(&(file_io_port->client_info->cs));

	return 0;
}